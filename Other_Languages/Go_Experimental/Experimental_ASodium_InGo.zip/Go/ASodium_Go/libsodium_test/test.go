package main

import (
	"ASodium/sodiumpasswordhashargon2"
	"ASodium/sodiumrng"
	"fmt"
)

func main() {
	var testrandombytes []byte
	testrandombytes = sodiumrng.GetRandomBytes(32)
	testpasswordhash, myerror := sodiumpasswordhashargon2.Argon2HashPassword(testrandombytes, sodiumpasswordhashargon2.INTERACTIVE, false)
	fmt.Println(testpasswordhash)
	if myerror != nil {
		fmt.Println(myerror.Error())
	}
}
