﻿using System;

namespace ASodium
{
    public class SodiumKeyExchangeSharedSecretBox
    {
        public Byte[] ReadSharedSecret { get; set; }

        public Byte[] TransferSharedSecret { get; set; }
    }
}
