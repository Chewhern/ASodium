﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ASodium;
using System.Runtime.InteropServices;
using System.IO;

namespace LibSodiumBinding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Byte[] NET472 = File.ReadAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\C# Language Binding\\ASodium\\bin\\Debug\\net472\\ASodium.dll");
            Byte[] NETCOREAPP31 = File.ReadAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\C# Language Binding\\ASodium\\bin\\Debug\\netcoreapp3.1\\ASodium.dll");
            Byte[] NETSTANDARD20 = File.ReadAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\C# Language Binding\\ASodium\\bin\\Debug\\netstandard2.0\\ASodium.dll");
            RevampedKeyPair MyKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            RevampedKeyPair MyKeyPair2 = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            RevampedKeyPair MyKeyPair3 = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\NET472SK.txt",MyKeyPair.PrivateKey);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\NETCOREAPP31SK.txt", MyKeyPair2.PrivateKey);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\NETSTANDARD20SK.txt", MyKeyPair3.PrivateKey);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\NET472PK.txt", MyKeyPair.PublicKey);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\NETCOREAPP31PK.txt", MyKeyPair2.PublicKey);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\NETSTANDARD20PK.txt", MyKeyPair3.PublicKey);
            Byte[] SignedNET472 = SodiumPublicKeyAuth.Sign(NET472, MyKeyPair.PrivateKey);
            Byte[] SignedNETCOREAPP31 = SodiumPublicKeyAuth.Sign(NETCOREAPP31, MyKeyPair2.PrivateKey);
            Byte[] SignedNETSTANDARD20 = SodiumPublicKeyAuth.Sign(NETSTANDARD20, MyKeyPair3.PrivateKey);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\SignedNET472.txt", SignedNET472);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\SignedNETCOREAPP31.txt", SignedNETCOREAPP31);
            File.WriteAllBytes("C:\\Users\\chew\\Desktop\\HernITSoftware\\Nuget API Keys\\ASodium\\SignedNETSTANDARD20.txt", SignedNETSTANDARD20);
        }
    }
}
